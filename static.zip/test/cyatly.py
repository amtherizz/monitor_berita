# import requests,json,uuid
# idusr,idsys = str(uuid.uuid4()),str(uuid.uuid4())
# headers = {
#     'User-Agent': 'ktor-client',
#     'Accept': 'application/json,text/event-stream',
#     'streaming': 'true',
#     'x-accel-buffering': 'no',
#     'accept-charset': 'UTF-8',
#     'authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIzYzM1YTRiMi1mZGRhLTQyOGUtYWZhNi1jYTVkMzE3YzYxYTYiLCJpbnRlZ3JpdHlDaGVjayI6dHJ1ZSwiYmFzZVVybCI6ImNoYXRseTovL29hdXRoIiwicHJvZHVjdFZhbGlkRm9yIjoiQ0hBVExZIiwiaWF0IjoxNzU2MTA3NDQyLCJleHAiOjE3NTYxMjkwNDIsInN1YiI6IjNjMzVhNGIyLWZkZGEtNDI4ZS1hZmE2LWNhNWQzMTdjNjFhNiJ9.eA5XZM38lyVl36NF6oD4gd9wPqXyfugBOS0ov4wvQUM',
# }
# files = {
#     'data': (None, json.dumps({
#   "id": "109dc4ec-cbcf-41fb-95d2-5e49b2076cce",
#   "model": "vgpt-g3-m",
#   "messages": [
#                 {
#                     "content": [
#                             {
#                               "type": "text",
#                               "text": "hai"
#                             }
#                           ],
#                     "id": idusr,
#                     "role": "user",
#                     "model": "vgpt-g2-4"
#                 }
#             ],
#   "temperature": 0.5,
#   "stream": False
# }), None, {'Content-Type': 'application/json'}),
# }

# response = requests.post('https://streaming-chatly.vyro.ai/v1/chat/completions', headers=headers, files=files)
# print(response.text)
import requests,time
# import subprocess

# # solver = subprocess.Popen([
# #     "solver",
# #     "--port", "8088",
# #     "--secret", "jWRN7DH6",
# #     "--browser-position",
# #     "--max-attempts", "3",
# #     "--captcha-timeout", "30",
# #     "--page-load-timeout", "30",
# #     "--reload-on-overrun"
# # ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
# # time.sleep(3)

# SERVER_URL = "http://127.0.0.1:8088"

# url = f"{SERVER_URL}/solve"

# headers = {
#   'ngrok-skip-browser-warning': '_',
#   'secret': 'jWRN7DH6',
#   'Content-Type': 'application/json'
# }

# json_data = {
#   "site_url": "https://accounts.vyro.ai/auth/sign-in/email?redirect=chatly%3A%2F%2Foauth%2Fvyro&isSubscribed=true&email=muhamadidris2025%40hotmail.com",
#   "site_key": "0x4AAAAAAAKHJu0Qox2uqsT2sss"
# }

# response = requests.get(

#   url=url,
#   headers=headers,
#   json=json_data,
# )

# response.raise_for_status()
# data = response.json()

# {
#   "elapsed": "2.641519",
#   "message": null,
#   "status": "OK",
#   "token": "0.MwOLQ3dg..."
# }

# token = data['token']
token = "0.rgVeLRlC-8mmwHz4sHPEimV2hReKbz5yKWdyz2opuO_Cfxk6LIFvMAACUmSYHY2Kw52E03hb-19l6ZxTWjqgba5UVPd-zVwufZExyVc1HoCRlj1NCl98KP0PJZZO_OsZJNlaLvYDeIU_obDkeDRHF7JvwB8BEFXXwNn2GmKIjCkWgfnxWndVKhf0oQbKxGbhK5RESkt90ISu4bmf_PeGYxcH43kvBnZn2rRv8EslFqLWPF5UfPCbUHj3uPm2Tu1XcFG_eTALzksLYtENzopaJ60sOORueRUXckZUq8GODOhGYWv4twz0LCS5cLzE1SehK3cs2_MAIngHMOUGUMzN1wSfRN0VqWn8g1Jd9pM3Dtdky8x5Im-Nt-qwn43pXCwzA_II2jgsUwQShcpZWU3BmmD_Ope2cnuP7hrzZrnuyiFu69uhCTkneyoH4WOZL9mc5cBLMr_8XeCAUkIzY98AnKndRUbWfcwIbIz1yZmSwOmRKvuUIL68Gbh3sKkj3dAXZDCtfZvdWS8rx4iWADFL5mjKp88HIqe04QBPS49LO9chwsch2i3U4L_XO2INrYz2e4AZM7k4wPDyfNAWb3vsNYLLOMFqoh3rxV17J1yipAOLAYxLwUvpwboHApUGqUNKW0GOcmHaeMs1VEr7Ac8dQcHPB5nPWCon9cjWv2pEHXoMHT5nXM72z7tjJd1WxOFw6SqwLUghFSORTwtptxUAu6YF-pGiue_zecQJETICwiotKKmEkFFqbIuRwO0OMibhjWEtvzkz5rBskpvkotWJc3Nq_cf7D-9PvEnwfZ5JrTlytZkovTRnRTzjibSfA-Pi5J-_zjovML7CwVZqN5L048pL3hyPueeGXGgPabE2QNmOAmNcwwpMnVRkXQSKDLuB.zgC4RdS_lM0TqfeHlvVqhw.c39c7704121fa67e21c7f816bbc4f7e7be766e6bc85c58b50d81fe4652651457" 
print(token)
import json,time
url = "https://auth.vyro.ai/apis/v1/auth/custom/login?redirect=chatly:%2F%2Foauth%2Fvyro&isSubscribed=true"

payload = {
  "email": "muhamadidris2025@hotmail.com",
  "password": ",PL'&j^ift.$,89",
  "captcha": token,
  "isSubscribed": True
}

headers = {
  'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:142.0) Gecko/20100101 Firefox/142.0",
  'Accept': "application/json, text/plain, */*",
  'Accept-Encoding': "gzip, deflate, br, zstd",
  'Content-Type': "application/json",
  'accept-language': "id,en-US;q=0.7,en;q=0.3",
  'origin': "https://accounts.vyro.ai",
  'referer': "https://accounts.vyro.ai/",
  'sec-fetch-dest': "empty",
  'sec-fetch-mode': "cors",
  'sec-fetch-site': "same-site",
  'priority': "u=0",
  'te': "trailers"
}

response = requests.post(url, data=json.dumps(payload), headers=headers).json()
result = response.get('result')
print(response)
if result:
    token : str = result['redirect']
    url = "https://auth.vyro.ai/apis/v1/auth/other/user-info?token=" + token.replace('chatly://oauth/vyro?token=','')
    bearer : dict = requests.get(url).json()
    bearer = bearer.get('result').get('sessionToken')
    print(bearer)

# solver.terminate()